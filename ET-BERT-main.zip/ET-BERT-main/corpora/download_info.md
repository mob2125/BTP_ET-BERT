******
encrypted traffic burst corpora download link
******

[ET-BERT corpora](https://drive.google.com/file/d/1P1Ru6my9QeJs0Mj6vGA4DyGJFXuI9_6t/view?usp=sharing)
