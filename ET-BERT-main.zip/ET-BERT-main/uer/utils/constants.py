# Special token words.
CLS_TOKEN = "[CLS]"
SEP_TOKEN = "[SEP]"
MASK_TOKEN = "[MASK]"
SENTINEL_TOKEN = "[extra_id_0]" # [extra_id_0], [extra_id_1], ... , should have consecutive IDs.

# Special token words.
PAD_ID = 0
