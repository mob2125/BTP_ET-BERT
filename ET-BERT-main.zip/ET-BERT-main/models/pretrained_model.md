******
pre-trained ET-BERT
******

[ET-BERT pretrained model](https://drive.google.com/drive/folders/1aIDHlsKOdTDwMn3dltci3aqKX41m8G76?usp=sharing)
